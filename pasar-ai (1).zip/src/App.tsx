import React, { useState, useRef } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  Camera, 
  Upload, 
  Image as ImageIcon, 
  Loader2, 
  Copy, 
  Check, 
  Store,
  TrendingUp,
  Download,
  X,
  Plus,
  Sparkles,
  Smartphone,
  Zap,
  Languages,
  Mic,
  MicOff,
  Square,
  MessageSquare
} from 'lucide-react';
import Markdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { motion, AnimatePresence } from 'motion/react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface MarketingCopy {
  bm: string;
  en: string;
  cn: string;
}

const SYSTEM_INSTRUCTION = `You are Pasar-AI, a Malaysian SME Growth Expert. You help local business owners turn photos of their products into professional marketing copy and provide advice on government grants.

KNOWLEDGE BASE (SME Digital Grants Malaysia):
- Geran Digital PMKS Madani: Provides up to 50% matching grant or RM5,000 per company.
- Eligibility:
  - At least 51% Malaysian owned.
  - Registered with SSM/Local Authority/Professional Body.
  - In operation for at least 6 months.
  - Minimum annual turnover of RM50,000.
- Focus Areas: Digital Marketing, E-commerce, HR/Payroll, ERP/Accounting, POS systems, Remote Working.
- How to apply: Through MDEC authorized Technology Solution Providers (TSPs).

When given one or more images and optionally a business description:
1. Analyze the product(s) and the business context.
2. Generate professional, highly engaging marketing copy in three languages: Bahasa Malaysia, English, and Mandarin (Simplified Chinese).
3. For EACH language, provide:
   - A catchy Headline (with emojis! 🚀).
   - A friendly Product Description (use bullet points and emojis 🍱).
   - A TikTok Script/Caption (high energy, trend-focused, lots of emojis 🎥✨).
   - A Shopee Product Description (clear, informative, use checkmarks ✅ and highlight "Ready Stock").
   - An Instagram Caption (aesthetic, lifestyle-focused, includes 5-10 relevant hashtags 📸✨).
   - A WhatsApp Blast Message (short, direct, clear call-to-action, use bolding for emphasis 📱💬).
   - A Facebook Post (community-focused, encourages comments/shares, friendly tone 👥🔥).
   - 3 Growth Tips specific to the product (practical and encouraging 💡).
   - **Grant Advice Section**: Based on the business description and product, check if they might qualify for the Geran Digital PMKS Madani. Give a short "Boss, you might qualify for RM5,000 grant!" style advice if relevant.
4. TONE GUIDELINES:
   - Bahasa Malaysia (BM): Sound like a friendly local stall owner (Abang/Kakak/Mak Cik). Use warm, welcoming language like "Jemput datang Boss!", "Sedap giler!", "Memang padu!". Use plenty of local emojis 🇲🇾🔥.
   - English: Professional yet friendly Malaysian English with a touch of local flair 🌟.
   - Mandarin: Friendly and persuasive Simplified Chinese with appropriate emojis 🧧.
5. PLATFORM OPTIMIZATION:
   - TikTok: Focus on trends and high energy.
   - Shopee: Focus on clarity and "Ready Stock".
   - Instagram: Focus on visuals and hashtags.
   - WhatsApp: Focus on speed and direct ordering.
   - Facebook: Focus on storytelling and community.

IMPORTANT: Use emojis generously to make the text visually appealing and "pop"! Format with clear headings and spacing.

Output the result as a JSON object with keys 'bm', 'en', and 'cn'. Each value should be a beautifully formatted Markdown string containing all the sections mentioned above.`;

export default function App() {
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [copy, setCopy] = useState<MarketingCopy | null>(null);
  const [copiedLang, setCopiedLang] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'bm' | 'en' | 'cn'>('bm');
  const [businessDesc, setBusinessDesc] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
        await transcribeAudio(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Mic error:", err);
      alert("Boss, mic not working lah. Check permissions?");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const transcribeAudio = async (blob: Blob) => {
    setTranscribing(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64Audio = (reader.result as string).split(',')[1];
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
        
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: [
            {
              parts: [
                { text: "This is a Malaysian business owner describing their business in Manglish. Transcribe it accurately and then provide a 1-sentence summary of their business goals. Format: [Transcription] --- [Summary]" },
                { inlineData: { mimeType: "audio/webm", data: base64Audio } }
              ]
            }
          ]
        });

        const text = response.text || "";
        setBusinessDesc(prev => prev + (prev ? "\n" : "") + text);
      };
    } catch (error) {
      console.error("Transcription error:", error);
    } finally {
      setTranscribing(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setImages(prev => [...prev, reader.result as string]);
          setCopy(null);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
    setCopy(null);
  };

  const generateMarketing = async () => {
    if (images.length === 0) return;

    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      const imageParts = images.map(img => ({
        inlineData: {
          mimeType: "image/jpeg",
          data: img.split(',')[1]
        }
      }));

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            parts: [
              { text: `Analyze these images and the business context provided below. Generate a full marketing plan in BM, English, and Mandarin. 
              
              BUSINESS CONTEXT:
              ${businessDesc || "No specific context provided."}

              For each language, include a Headline, Product Description, TikTok Script/Caption, Shopee Description, Instagram Caption, WhatsApp Message, Facebook Post, 3 Growth Tips, and a Grant Advice section (check eligibility for Geran Digital PMKS Madani). 
              
              Return the response as a JSON object with keys 'bm', 'en', and 'cn'.` },
              ...imageParts
            ]
          }
        ],
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              bm: { type: Type.STRING, description: "Full marketing plan in Bahasa Malaysia including TikTok, Shopee, Instagram, WhatsApp, and Facebook sections" },
              en: { type: Type.STRING, description: "Full marketing plan in English including TikTok, Shopee, Instagram, WhatsApp, and Facebook sections" },
              cn: { type: Type.STRING, description: "Full marketing plan in Mandarin including TikTok, Shopee, Instagram, WhatsApp, and Facebook sections" }
            },
            required: ["bm", "en", "cn"]
          }
        }
      });

      const result = JSON.parse(response.text || "{}");
      setCopy(result);
    } catch (error) {
      console.error("AI Error:", error);
      alert("Aiyo Boss, something went wrong. Try again lah?");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, lang: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLang(lang);
    setTimeout(() => setCopiedLang(null), 2000);
  };

  const downloadMarketingKit = () => {
    if (!copy) return;
    const content = `PASAR-AI MARKETING KIT\n\nBAHASA MALAYSIA:\n${copy.bm}\n\nENGLISH:\n${copy.en}\n\nMANDARIN:\n${copy.cn}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Pasar-AI-Marketing-Kit.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#fdfcfb] pb-12 font-sans selection:bg-orange-100 selection:text-orange-900">
      {/* Dynamic Background */}
      <div className="fixed inset-0 -z-10 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-orange-50 via-white to-orange-50/30 opacity-70" />

      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-orange-100 sticky top-0 z-50 shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-orange-200">
              <Store size={22} strokeWidth={2.5} />
            </div>
            <h1 className="text-2xl font-black tracking-tighter text-gray-900">Pasar<span className="text-orange-600">AI</span></h1>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-orange-50 rounded-full border border-orange-100">
              <Sparkles size={14} className="text-orange-500" />
              <span className="text-[10px] font-bold text-orange-700 uppercase tracking-widest">SME Growth Expert</span>
            </div>
          </motion.div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 mt-10">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl sm:text-5xl font-black text-gray-900 tracking-tight mb-4"
          >
            Turn Photos into <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-red-600">Sales</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-gray-500 max-w-xl mx-auto text-lg font-medium"
          >
            Upload your product photos and let our AI generate professional marketing copy in 3 languages lah! 🇲🇾
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Input Section */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-5 space-y-6"
          >
            <section className="bg-white p-8 rounded-[2.5rem] shadow-xl shadow-orange-100/50 border border-orange-50 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-400 to-red-500" />
              
              <h2 className="text-xl font-bold mb-6 flex items-center gap-3 text-gray-800">
                <div className="p-2 bg-orange-50 rounded-lg">
                  <Camera size={20} className="text-orange-600" />
                </div>
                Snap Your Product
              </h2>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <AnimatePresence>
                  {images.map((img, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="relative aspect-square rounded-3xl overflow-hidden border-2 border-orange-50 group shadow-md"
                    >
                      <img src={img} alt={`Upload ${idx}`} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" referrerPolicy="no-referrer" />
                      <button 
                        onClick={() => removeImage(idx)}
                        className="absolute top-3 right-3 bg-white/90 text-red-600 p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all backdrop-blur-sm shadow-lg hover:bg-red-50"
                      >
                        <X size={16} strokeWidth={3} />
                      </button>
                    </motion.div>
                  ))}
                </AnimatePresence>
                
                {images.length < 4 && (
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => fileInputRef.current?.click()}
                    className="aspect-square rounded-3xl border-3 border-dashed border-orange-100 flex flex-col items-center justify-center bg-orange-50/30 hover:border-orange-400 hover:bg-orange-50 transition-all group"
                  >
                    <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center shadow-sm group-hover:shadow-md transition-all">
                      <Plus size={28} className="text-orange-400 group-hover:text-orange-600 transition-colors" />
                    </div>
                    <span className="text-[10px] font-black text-orange-400 group-hover:text-orange-600 mt-3 uppercase tracking-[0.2em]">Add Photo</span>
                  </motion.button>
                )}
              </div>

              {images.length === 0 && (
                <motion.div 
                  whileHover={{ y: -4 }}
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-video rounded-[2rem] border-3 border-dashed border-orange-100 flex flex-col items-center justify-center cursor-pointer bg-orange-50/20 hover:border-orange-400 transition-all mb-6 group"
                >
                  <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-lg mb-4 group-hover:scale-110 transition-transform">
                    <Upload className="text-orange-500" size={32} />
                  </div>
                  <p className="font-bold text-gray-800 text-lg">Upload Your Item</p>
                  <p className="text-sm text-orange-400 font-medium mt-1">Show us your product Boss! 📸</p>
                </motion.div>
              )}

              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
                accept="image/*" 
                multiple
                className="hidden" 
              />

              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                    <MessageSquare size={16} className="text-orange-500" />
                    Describe Your Business (Manglish OK!)
                  </label>
                  <button
                    onClick={isRecording ? stopRecording : startRecording}
                    className={cn(
                      "p-2 rounded-full transition-all shadow-sm",
                      isRecording ? "bg-red-500 text-white animate-pulse" : "bg-orange-100 text-orange-600 hover:bg-orange-200"
                    )}
                  >
                    {isRecording ? <Square size={18} fill="currentColor" /> : <Mic size={18} />}
                  </button>
                </div>
                <textarea
                  value={businessDesc}
                  onChange={(e) => setBusinessDesc(e.target.value)}
                  placeholder="Tell us about your business lah! 'I sell homemade sambal from Melaka, want to target young office workers...'"
                  className="w-full h-24 p-4 rounded-2xl bg-orange-50/30 border border-orange-100 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all resize-none placeholder:text-gray-400"
                />
                {transcribing && (
                  <p className="text-[10px] text-orange-500 font-bold mt-1 animate-pulse flex items-center gap-1">
                    <Loader2 size={10} className="animate-spin" />
                    Listening to your goals Boss...
                  </p>
                )}
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={images.length === 0 || loading}
                onClick={generateMarketing}
                className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white py-5 rounded-2xl font-black text-xl shadow-xl shadow-orange-200 hover:shadow-orange-300 transition-all disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center gap-3 relative overflow-hidden group"
              >
                <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
                {loading ? (
                  <>
                    <Loader2 className="animate-spin" size={26} />
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <>
                    <Zap size={26} fill="currentColor" />
                    <span>Generate Copy Lah!</span>
                  </>
                )}
              </motion.button>
            </section>

            {/* Feature Cards */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-5 rounded-3xl border border-orange-50 shadow-sm flex flex-col items-center text-center">
                <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center mb-3">
                  <Smartphone size={20} />
                </div>
                <p className="text-xs font-bold text-gray-800">Mobile Ready</p>
                <p className="text-[10px] text-gray-400 mt-1">Post straight to socials</p>
              </div>
              <div className="bg-white p-5 rounded-3xl border border-orange-50 shadow-sm flex flex-col items-center text-center">
                <div className="w-10 h-10 bg-green-50 text-green-500 rounded-full flex items-center justify-center mb-3">
                  <Languages size={20} />
                </div>
                <p className="text-xs font-bold text-gray-800">3 Languages</p>
                <p className="text-[10px] text-gray-400 mt-1">BM, EN & Mandarin</p>
              </div>
            </div>
          </motion.div>

          {/* Output Section */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-7 space-y-6"
          >
            {copy ? (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-black text-gray-900 flex items-center gap-3">
                    <Sparkles className="text-orange-500" size={28} />
                    Your Marketing Kit
                  </h2>
                  <motion.button 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={downloadMarketingKit}
                    className="flex items-center gap-2 bg-gray-900 text-white px-5 py-2.5 rounded-2xl text-sm font-black hover:bg-black transition-all shadow-lg shadow-gray-200"
                  >
                    <Download size={18} />
                    Download Kit
                  </motion.button>
                </div>

                {/* Tabs */}
                <div className="flex p-1.5 bg-white rounded-[2rem] shadow-md border border-orange-50">
                  {[
                    { id: 'bm', label: '🇲🇾 Bahasa', color: 'text-orange-600', bg: 'bg-orange-50' },
                    { id: 'en', label: '🇬🇧 English', color: 'text-blue-600', bg: 'bg-blue-50' },
                    { id: 'cn', label: '🇨🇳 中文', color: 'text-red-600', bg: 'bg-red-50' }
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={cn(
                        "flex-1 py-3 rounded-[1.5rem] text-sm font-black transition-all duration-300",
                        activeTab === tab.id 
                          ? cn("shadow-sm", tab.bg, tab.color) 
                          : "text-gray-400 hover:text-gray-600"
                      )}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                {/* Content Area */}
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="bg-white p-8 sm:p-10 rounded-[2.5rem] shadow-xl shadow-orange-100/50 border border-orange-50 relative min-h-[500px]"
                  >
                    <div className="absolute top-6 right-8">
                      <motion.button 
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => copyToClipboard(copy[activeTab], activeTab)}
                        className="text-gray-400 hover:text-orange-500 transition-colors p-3 rounded-2xl bg-gray-50 hover:bg-orange-50 border border-gray-100"
                      >
                        {copiedLang === activeTab ? <Check size={22} className="text-green-500" strokeWidth={3} /> : <Copy size={22} />}
                      </motion.button>
                    </div>

                    <div className="prose prose-orange prose-lg max-w-none text-gray-700 leading-relaxed custom-markdown">
                      <Markdown>{copy[activeTab]}</Markdown>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>
            ) : (
              <div className="bg-white p-16 rounded-[3rem] shadow-xl shadow-orange-100/30 border border-orange-50 flex flex-col items-center justify-center text-center min-h-[600px]">
                <motion.div 
                  animate={{ 
                    y: [0, -10, 0],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{ 
                    duration: 4, 
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="w-24 h-24 bg-orange-50 rounded-[2rem] flex items-center justify-center mb-8 shadow-inner"
                >
                  <ImageIcon className="text-orange-200" size={48} />
                </motion.div>
                <h3 className="text-2xl font-black text-gray-900 mb-3 tracking-tight">Ready to Grow Boss?</h3>
                <p className="text-gray-400 max-w-xs font-medium leading-relaxed">
                  Upload your product photos and we'll generate professional copy with emojis to make your posts pop! 🚀
                </p>
                
                <div className="mt-10 flex gap-3">
                  <div className="w-2 h-2 rounded-full bg-orange-200 animate-bounce" />
                  <div className="w-2 h-2 rounded-full bg-orange-300 animate-bounce [animation-delay:0.2s]" />
                  <div className="w-2 h-2 rounded-full bg-orange-400 animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
          </motion.div>

        </div>
      </main>

      <footer className="max-w-6xl mx-auto px-6 mt-20 text-center">
        <div className="h-px bg-gradient-to-r from-transparent via-orange-100 to-transparent mb-8" />
        <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em]">
          PASAR-AI &copy; 2026 • BUILT FOR MALAYSIAN SMEs • <span className="text-orange-500">MANTAP LAH!</span>
        </p>
      </footer>

      <style>{`
        .custom-markdown h1, .custom-markdown h2, .custom-markdown h3 {
          color: #111827;
          font-weight: 900;
          letter-spacing: -0.025em;
          margin-top: 2rem;
          margin-bottom: 1rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        .custom-markdown h1 { font-size: 1.875rem; border-bottom: 3px solid #ffedd5; padding-bottom: 0.5rem; }
        .custom-markdown h2 { font-size: 1.5rem; }
        .custom-markdown h3 { font-size: 1.25rem; }
        .custom-markdown p { margin-bottom: 1.25rem; }
        .custom-markdown ul { list-style-type: none; padding-left: 0; }
        .custom-markdown li { 
          position: relative; 
          padding-left: 1.5rem; 
          margin-bottom: 0.75rem;
          background: #fffaf5;
          padding: 1rem 1rem 1rem 2rem;
          border-radius: 1rem;
          border-left: 4px solid #f97316;
        }
        .custom-markdown li::before {
          content: "✨";
          position: absolute;
          left: 0.5rem;
          top: 1rem;
        }
        .custom-markdown strong { color: #ea580c; font-weight: 800; }
        
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #fed7aa; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #fb923c; }
      `}</style>
    </div>
  );
}
